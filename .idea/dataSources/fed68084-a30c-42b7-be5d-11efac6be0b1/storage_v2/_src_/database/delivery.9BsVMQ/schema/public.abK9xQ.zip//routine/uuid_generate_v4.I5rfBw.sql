create function uuid_generate_v4()
  returns uuid
language c
as $$
uuid_generate_v4
$$;

