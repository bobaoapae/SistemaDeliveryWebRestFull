create function uuid_generate_v5(namespace uuid, name text)
  returns uuid
language c
as $$
uuid_generate_v5
$$;

