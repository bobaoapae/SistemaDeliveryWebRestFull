create function uuid_nil()
  returns uuid
language c
as $$
uuid_nil
$$;

