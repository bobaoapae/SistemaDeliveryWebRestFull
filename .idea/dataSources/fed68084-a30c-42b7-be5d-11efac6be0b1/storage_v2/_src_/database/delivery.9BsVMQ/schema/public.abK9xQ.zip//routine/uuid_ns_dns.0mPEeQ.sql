create function uuid_ns_dns()
  returns uuid
language c
as $$
uuid_ns_dns
$$;

