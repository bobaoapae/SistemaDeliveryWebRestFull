create function uuid_ns_url()
  returns uuid
language c
as $$
uuid_ns_url
$$;

