create function uuid_generate_v1mc()
  returns uuid
language c
as $$
uuid_generate_v1mc
$$;

