create function uuid_ns_x500()
  returns uuid
language c
as $$
uuid_ns_x500
$$;

